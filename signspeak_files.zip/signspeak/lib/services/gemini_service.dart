import 'package:google_generative_ai/google_generative_ai.dart';

/// Handles sentence completion using Gemini Nano (on-device via AICore).
/// Falls back to rule-based assembly if Gemini is unavailable.
class GeminiService {
  GenerativeModel? _model;
  ChatSession? _chat;
  bool _isAvailable = false;

  // Conversation history for context (last 3 exchanges)
  final List<Map<String, String>> _history = [];
  static const int _maxHistory = 3;

  static const String _systemPrompt = '''You are a sign language interpreter assistant.
Your job is to convert ASL sign tokens into natural, fluent English sentences.

Important rules:
- ASL omits articles (a, the), auxiliaries (is, are, was), and sometimes pronouns
- Input tokens are uppercase ASL signs detected from a camera
- Output ONLY the final natural English sentence — nothing else, no explanation
- Keep sentences concise and natural (under 15 words)
- If context from previous sentences helps, use it

Examples:
Input: WATER NEED → Output: I need some water please.
Input: NAME MY JOHN → Output: My name is John.
Input: HELP ME PLEASE → Output: Could you please help me?
Input: HUNGRY I FOOD WANT → Output: I'm hungry and want some food.
Input: BATHROOM WHERE → Output: Where is the bathroom?
Input: THANK YOU → Output: Thank you.''';

  Future<void> initialize() async {
    try {
      // Try Gemini Nano on-device first (Android 14+ / Pixel 8)
      // Uses the special 'gemini-nano' model identifier for AICore
      _model = GenerativeModel(
        model: 'gemini-nano',
        // No API key needed for on-device AICore
        systemInstruction: Content.system(_systemPrompt),
        generationConfig: GenerationConfig(
          maxOutputTokens: 50,
          temperature: 0.3, // Low temp = more predictable sentence output
        ),
      );
      // Test with a simple prompt to verify availability
      await _model!.generateContent([Content.text('HELLO')]);
      _isAvailable = true;
      _startNewChat();
    } catch (e) {
      // Gemini Nano not available — use rule-based fallback
      _isAvailable = false;
      _model = null;
    }
  }

  void _startNewChat() {
    _chat = _model?.startChat(history: []);
    _history.clear();
  }

  Future<String> completeSentence(List<String> tokens) async {
    if (tokens.isEmpty) return '';

    final tokenString = tokens.join(' ');

    if (_isAvailable && _model != null) {
      try {
        // Build prompt with recent history for context
        String prompt = tokenString;
        if (_history.isNotEmpty) {
          final ctx = _history
              .take(_maxHistory)
              .map((h) => 'Previous: "${h['output']}"')
              .join('\n');
          prompt = '$ctx\nNow convert: $tokenString';
        }

        final response = await _chat!.sendMessage(Content.text(prompt));
        final output = response.text?.trim() ?? _ruleBased(tokens);

        // Store in history
        _history.insert(0, {'input': tokenString, 'output': output});
        if (_history.length > _maxHistory) _history.removeLast();

        return output;
      } catch (e) {
        return _ruleBased(tokens);
      }
    }

    return _ruleBased(tokens);
  }

  /// Simple rule-based fallback when Gemini Nano is unavailable
  String _ruleBased(List<String> tokens) {
    if (tokens.isEmpty) return '';

    final lower = tokens.map((t) => t.toLowerCase()).toList();

    // Handle common single-token phrases
    if (tokens.length == 1) {
      final single = lower.first;
      final map = {
        'hello': 'Hello!',
        'thank_you': 'Thank you.',
        'thanks': 'Thanks.',
        'yes': 'Yes.',
        'no': 'No.',
        'please': 'Please.',
        'sorry': 'I am sorry.',
        'help': 'I need help.',
        'stop': 'Please stop.',
        'ok': 'Okay.',
      };
      return map[single] ?? _capitalize(single) + '.';
    }

    // Simple subject insertion
    final hasSubject = lower.contains('i') ||
        lower.contains('you') ||
        lower.contains('we') ||
        lower.contains('my');

    final words = lower.map(_capitalize).toList();

    if (!hasSubject) {
      return 'I ${words.join(' ').toLowerCase()}.';
    }
    return '${words.join(' ')}.';
  }

  String _capitalize(String s) =>
      s.isEmpty ? s : s[0].toUpperCase() + s.substring(1).toLowerCase();

  void resetContext() => _startNewChat();

  bool get isOnDevice => _isAvailable;

  void dispose() {
    _model = null;
    _chat = null;
  }
}
